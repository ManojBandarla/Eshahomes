package Isha.Homes;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.google.common.io.Files;
import org.openqa.selenium.edge.EdgeDriver;
 
public class miniProject {
 
	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		
		//creating Webdriver object 
        WebDriver driver = new EdgeDriver();
        
        //launch the browser
		driver.get("https://ishahomes.com/");
		
		
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		
		
		driver.findElement(By.xpath("//*[@id=\"menu-item-25810\"]/a")).click();

		// xpath for completed projects by isha homes.
		List<WebElement> elements = driver.findElements(By.xpath("//div[@class='item-listing-wrap hz-item-gallery-js item-listing-wrap-v6 card amadadalda']"));
        System.out.println("Total number of completed projects : " + elements.size()/2);

        String name1 = driver.findElement(By.xpath("//a[text()='Isha Avni']")).getText();
		String name2 = driver.findElement(By.xpath("//a[text()='Isha Ishtabhumi']")).getText();
		String name3 = driver.findElement(By.xpath("//a[text()='Isha Lakefront']")).getText();
		String name4 = driver.findElement(By.xpath("//a[text()='Isha Santhosham']")).getText();
		String name5 = driver.findElement(By.xpath("//a[text()='Isha Anandham']")).getText();
		System.out.println("");
		System.out.println("First five completed projects of Isha Homes : ");
		System.out.println( name1 );
		System.out.println( name2 );
		System.out.println( name3 );
		System.out.println( name4 );
		System.out.println( name5 );
		System.out.println();
		//scrolldown
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,4200)", "");
		//xpath for the enquire button.
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div[7]/div[2]/a")).click();
		// checking the contact info option present on the page are not  :
		String value = driver.findElement(By.xpath("//div[@class='dialog-widget-content dialog-lightbox-widget-content animated']")).getText();
		String value2 = "Contact Info";
		if(value.equals(value2)) 
		{
			System.out.println("Contact Info is present on page");
		}
		else 
		{
			System.out.println("Contact Info is not present on page");
		}
		System.out.println();
		// Displaying the vendor info of isha homes for any further process :
       driver.findElement(By.xpath("//*[@id=\"elementor-popup-modal-32248\"]/div/div[2]/div/section[2]/div/div/div/section/div/div/div/div/div/ul/li[3]/a/span[2]")).click();
	   String href = driver.findElement(By.xpath("//*[@id=\"elementor-popup-modal-31897\"]/div/div[2]/div/section/div/div/div/div[2]/div/div/a")).getAttribute("href");
	   System.out.println("contact info of isha homes for any further process :");
	   System.out.println(href);
	   System.out.println();
	    // Taking screenshot code..
		File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\2323698\\OneDrive - Cognizant\\Desktop\\temp\\Homes\\target\\IshaHomes4.jpg"));
		System.out.println("Screenshot captured Successfully !!! ");
 
		// Quiting the browser..
//		driver.quit();
		
		driver.close();
	}
 
}